from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure
import logging
from app.config import Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MongoDBClient:
    def __init__(self):
        self.client = None
        self.db = None
        self.collection = None
        self.connect()
    
    def connect(self):
        try:
            self.client = MongoClient(Config.MONGODB_URI)
            self.client.admin.command('ping')
            self.db = self.client[Config.DATABASE_NAME]
            self.collection = self.db[Config.COLLECTION_NAME]
            logger.info(f"Successfully connected to MongoDB at {Config.MONGODB_URI}")
            return True
        except ConnectionFailure as e:
            logger.error(f"Failed to connect to MongoDB: {e}")
            return False
    
    def insert_reviews(self, reviews):
        try:
            if isinstance(reviews, list):
                result = self.collection.insert_many(reviews)
            else:
                result = self.collection.insert_one(reviews)
            logger.info(f"Inserted {len(reviews) if isinstance(reviews, list) else 1} reviews")
            return result
        except OperationFailure as e:
            logger.error(f"Failed to insert reviews: {e}")
            return None
    
    def get_all_reviews(self):
        try:
            return list(self.collection.find())
        except OperationFailure as e:
            logger.error(f"Failed to fetch reviews: {e}")
            return []
    
    def get_reviews_by_segment(self, segment):
        try:
            return list(self.collection.find({'segment': segment}))
        except OperationFailure as e:
            logger.error(f"Failed to fetch reviews by segment: {e}")
            return []
    
    def update_review_segment(self, review_id, segment):
        try:
            result = self.collection.update_one(
                {'_id': review_id},
                {'$set': {'segment': segment}}
            )
            return result.modified_count > 0
        except OperationFailure as e:
            logger.error(f"Failed to update review segment: {e}")
            return False
    
    def get_segment_statistics(self):
        try:
            pipeline = [
                {'$group': {
                    '_id': '$segment',
                    'count': {'$sum': 1},
                    'avg_rating': {'$avg': '$rating'},
                    'avg_sentiment': {'$avg': '$sentiment_score'}
                }}
            ]
            return list(self.collection.aggregate(pipeline))
        except OperationFailure as e:
            logger.error(f"Failed to get segment statistics: {e}")
            return []
    
    def close(self):
        if self.client:
            self.client.close()
            logger.info("MongoDB connection closed")