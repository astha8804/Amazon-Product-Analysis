import json
from datetime import datetime
from typing import Any, Dict
import re

def format_date(date: datetime) -> str:
    if isinstance(date, datetime):
        return date.strftime('%Y-%m-%d %H:%M:%S')
    return str(date)

def sanitize_text(text: str) -> str:
    if not text:
        return ''
    text = re.sub(r'<[^>]+>', '', text)
    text = ' '.join(text.split())
    return text.strip()

def extract_keywords(text: str, max_keywords: int = 10) -> list:
    if not text:
        return []
    
    words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
    word_freq = {}
    stopwords = {'the', 'this', 'that', 'with', 'from', 'have', 'are', 'was', 'were', 'and', 'for'}
    
    for word in words:
        if word not in stopwords:
            word_freq[word] = word_freq.get(word, 0) + 1
    
    sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
    return [word for word, _ in sorted_words[:max_keywords]]

def parse_rating(rating_str: str) -> float:
    try:
        return float(rating_str)
    except (ValueError, TypeError):
        return 0.0

def create_response(success: bool, message: str, data: Any = None) -> Dict[str, Any]:
    response = {
        'success': success,
        'message': message,
        'timestamp': datetime.now().isoformat()
    }
    if data is not None:
        response['data'] = data
    return response

def validate_review_data(review_data: Dict[str, Any]) -> tuple:
    required_fields = ['review_text', 'rating']
    errors = []
    
    for field in required_fields:
        if field not in review_data:
            errors.append(f"Missing required field: {field}")
    
    if 'rating' in review_data:
        try:
            rating = float(review_data['rating'])
            if rating < 1 or rating > 5:
                errors.append("Rating must be between 1 and 5")
        except (ValueError, TypeError):
            errors.append("Rating must be a number")
    
    if errors:
        return False, errors
    return True, None