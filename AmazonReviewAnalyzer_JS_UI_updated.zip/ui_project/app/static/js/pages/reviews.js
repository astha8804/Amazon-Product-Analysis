import { api } from '../api.js';
import { stars, sentimentBadge, segmentBadge, truncate, emptyState } from '../utils.js';

const PAGE_SIZE = 10;
let state = { reviews: [], page: 1, filter: '' };

function renderTable(container) {
    const filtered = state.reviews.filter(r =>
        !state.filter ||
        (r.review_title || '').toLowerCase().includes(state.filter) ||
        (r.review_text || '').toLowerCase().includes(state.filter) ||
        (r.sentiment_label || '').toLowerCase().includes(state.filter) ||
        (r.segment || '').toLowerCase().includes(state.filter)
    );

    const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
    state.page = Math.min(state.page, totalPages);
    const start = (state.page - 1) * PAGE_SIZE;
    const pageRows = filtered.slice(start, start + PAGE_SIZE);

    const tbody = container.querySelector('#reviewsTableBody');
    tbody.innerHTML = pageRows.length ? pageRows.map((r, i) => `
        <tr>
            <td>${start + i + 1}</td>
            <td>
                <div class="title-text">${truncate(r.review_title || 'No Title', 40)}</div>
                <small style="color: var(--text-secondary); font-size: 11px;">${truncate(r.review_text || '', 60)}</small>
            </td>
            <td>${stars(r.rating)}</td>
            <td>${sentimentBadge(r.sentiment_label)}</td>
            <td>${segmentBadge(r.segment)}</td>
        </tr>
    `).join('') : emptyState('No reviews found. Load sample data to get started.');

    container.querySelector('#pageInfo').textContent = `Page ${state.page} of ${totalPages}`;
    container.querySelector('#prevPage').disabled = state.page <= 1;
    container.querySelector('#nextPage').disabled = state.page >= totalPages;
}

export async function mount(container) {
    let data;
    try {
        data = await api.visualizationData();
    } catch (e) {
        data = null;
    }

    state.reviews = data?.reviews ?? [];
    state.page = 1;
    state.filter = '';

    const total = data?.total_reviews ?? state.reviews.length;
    const avgRating = data ? Number(data.avg_rating || 0).toFixed(1) : '0.0';
    const positive = data?.sentiment_distribution?.positive ?? 0;
    const negative = data?.sentiment_distribution?.negative ?? 0;

    container.innerHTML = `
        <section class="stats-grid">
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Total Reviews</span><div class="stat-icon"><i class="fa-solid fa-file-alt"></i></div></div>
                <div class="stat-value">${total}</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Average Rating</span><div class="stat-icon"><i class="fa-solid fa-star"></i></div></div>
                <div class="stat-value">${avgRating}</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Positive</span><div class="stat-icon"><i class="fa-regular fa-face-smile"></i></div></div>
                <div class="stat-value">${positive}</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Negative</span><div class="stat-icon"><i class="fa-regular fa-face-frown"></i></div></div>
                <div class="stat-value">${negative}</div>
            </div>
        </section>

        <section class="table-section">
            <div class="table-header">
                <h3><i class="fa-regular fa-list"></i> All Reviews</h3>
                <div class="table-actions">
                    <button id="prevPage">← Previous</button>
                    <span id="pageInfo" style="align-self:center;color:var(--text-secondary);font-size:12px;"></span>
                    <button id="nextPage">Next →</button>
                </div>
            </div>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>#</th><th>Review</th><th>Rating</th><th>Sentiment</th><th>Segment</th></tr></thead>
                    <tbody id="reviewsTableBody"></tbody>
                </table>
            </div>
        </section>
    `;

    renderTable(container);

    container.querySelector('#prevPage').addEventListener('click', () => { state.page--; renderTable(container); });
    container.querySelector('#nextPage').addEventListener('click', () => { state.page++; renderTable(container); });

    const searchInput = document.getElementById('searchInput');
    const onSearch = () => {
        state.filter = searchInput.value.toLowerCase();
        state.page = 1;
        renderTable(container);
    };
    searchInput.addEventListener('keyup', onSearch);

    return () => searchInput.removeEventListener('keyup', onSearch);
}
