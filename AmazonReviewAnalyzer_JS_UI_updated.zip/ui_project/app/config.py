import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    MONGODB_URI = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/')
    DATABASE_NAME = os.getenv('DATABASE_NAME', 'amazon_review_db')
    COLLECTION_NAME = os.getenv('COLLECTION_NAME', 'reviews')
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key')

    # Real Amazon Reviews.csv dataset (place your file at this path, or override via .env)
    REVIEWS_CSV_PATH = os.getenv('REVIEWS_CSV_PATH', 'data/Reviews.csv')
    REVIEWS_CSV_DEFAULT_LIMIT = int(os.getenv('REVIEWS_CSV_DEFAULT_LIMIT', 5000))
    
    # Segmentation parameters
    SEGMENTATION_FEATURES = ['rating', 'sentiment_score', 'review_length']
    N_CLUSTERS = 4
    
    # Sentiment thresholds
    SENTIMENT_THRESHOLDS = {
        'positive': 0.1,
        'neutral': -0.1,
        'negative': -0.5
    }