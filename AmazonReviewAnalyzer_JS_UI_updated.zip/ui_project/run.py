﻿#!/usr/bin/env python3
import sys
import os
import logging

logging.getLogger('werkzeug').setLevel(logging.ERROR)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.main import create_app

if __name__ == '__main__':
    app = create_app()
    print("=" * 60)
    print("🛒 InsightCart - Amazon Review Analytics")
    print("=" * 60)
    print("📍 Dashboard: http://localhost:5000")
    print("📍 API Docs: http://localhost:5000/api")
    print("=" * 60)
    
    try:
        app.run(debug=True, host='0.0.0.0', port=5000)
    except OSError:
        print("\n⚠️ Port 5000 in use. Trying port 5001...")
        app.run(debug=True, host='0.0.0.0', port=5001)
