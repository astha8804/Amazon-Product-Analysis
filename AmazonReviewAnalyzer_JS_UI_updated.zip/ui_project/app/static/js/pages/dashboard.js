import { api } from '../api.js';
import { stars, sentimentBadge, segmentBadge, truncate, animateCount, emptyState, toast } from '../utils.js';
import { goTo } from '../router.js';

let charts = [];

function destroyCharts() {
    charts.forEach(c => c.destroy());
    charts = [];
}

export async function mount(container) {
    let data;
    try {
        data = await api.visualizationData();
    } catch (e) {
        data = null;
    }

    const total = data?.total_reviews ?? 0;
    const avgRating = data ? Number(data.avg_rating || 0).toFixed(1) : '0.0';
    const reviews = data?.reviews ?? [];
    const positive = data?.sentiment_distribution?.positive ?? 0;
    const negative = data?.sentiment_distribution?.negative ?? 0;
    const segmentDist = data?.segment_distribution ?? {};
    const segmentCount = Object.keys(segmentDist).length;
    const ratingDist = data?.rating_distribution ?? {};
    const sentimentDist = data?.sentiment_distribution ?? {};

    container.innerHTML = `
        <section class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-label">Total Reviews</span>
                    <div class="stat-icon"><i class="fa-solid fa-file-alt"></i></div>
                </div>
                <div class="stat-value" id="totalReviews">0</div>
                <div class="stat-change positive"><i class="fa-solid fa-arrow-up"></i> Live from database</div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-label">Average Rating</span>
                    <div class="stat-icon"><i class="fa-solid fa-star"></i></div>
                </div>
                <div class="stat-value" id="avgRating">0.0</div>
                <div class="stat-change positive"><i class="fa-solid fa-star"></i> out of 5.0</div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-label">Positive Reviews</span>
                    <div class="stat-icon"><i class="fa-regular fa-face-smile"></i></div>
                </div>
                <div class="stat-value" id="positiveCount">0</div>
                <div class="stat-change positive"><i class="fa-solid fa-arrow-up"></i> Positive sentiment</div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-label">Customer Segments</span>
                    <div class="stat-icon"><i class="fa-solid fa-layer-group"></i></div>
                </div>
                <div class="stat-value" id="segmentCount">0</div>
                <div class="stat-change positive"><i class="fa-solid fa-users"></i> Active clusters</div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <span class="stat-label">Negative Reviews</span>
                    <div class="stat-icon"><i class="fa-regular fa-face-frown"></i></div>
                </div>
                <div class="stat-value" id="negativeCount">0</div>
                <div class="stat-change negative"><i class="fa-solid fa-arrow-down"></i> Needs attention</div>
            </div>
        </section>

        <section class="charts-grid">
            <div class="chart-card">
                <div class="chart-header">
                    <h3><i class="fa-regular fa-circle"></i> Sentiment Distribution</h3>
                    <span class="chart-action" data-nav="reviews">View all →</span>
                </div>
                <canvas id="sentimentChart"></canvas>
            </div>
            <div class="chart-card">
                <div class="chart-header">
                    <h3><i class="fa-regular fa-star"></i> Rating Distribution</h3>
                    <span class="chart-action" data-nav="reviews">View all →</span>
                </div>
                <canvas id="ratingChart"></canvas>
            </div>
            <div class="chart-card">
                <div class="chart-header">
                    <h3><i class="fa-regular fa-user"></i> Customer Segments</h3>
                    <span class="chart-action" data-nav="segments">View all →</span>
                </div>
                <canvas id="segmentChart"></canvas>
            </div>
            <div class="chart-card">
                <div class="chart-header">
                    <h3><i class="fa-regular fa-chart-line"></i> Sentiment vs Rating</h3>
                    <span class="chart-action" data-nav="analytics">View all →</span>
                </div>
                <canvas id="scatterChart"></canvas>
            </div>
        </section>

        <section class="table-section">
            <div class="table-header">
                <h3><i class="fa-regular fa-list"></i> Recent Reviews</h3>
                <div class="table-actions">
                    <button id="btnViewAll">View All</button>
                    <button id="btnLoadSample"><i class="fa-solid fa-cloud-arrow-down"></i> Load Sample</button>
                    <button id="btnLoadCsv"><i class="fa-solid fa-file-csv"></i> Load My Dataset (CSV)</button>
                    <button id="btnSegment"><i class="fa-solid fa-microchip"></i> Segment</button>
                </div>
            </div>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr><th>Review</th><th>Rating</th><th>Sentiment</th><th>Segment</th></tr>
                    </thead>
                    <tbody id="reviewsTableBody"></tbody>
                </table>
            </div>
        </section>
    `;

    // ----- Populate table -----
    const tbody = container.querySelector('#reviewsTableBody');
    if (reviews.length) {
        tbody.innerHTML = reviews.slice(0, 20).map(r => `
            <tr>
                <td>
                    <div class="title-text">${truncate(r.review_title || 'No Title', 35)}</div>
                    <small style="color: var(--text-secondary); font-size: 11px;">${truncate(r.review_text || '', 50)}</small>
                </td>
                <td>${stars(r.rating)}</td>
                <td>${sentimentBadge(r.sentiment_label)}</td>
                <td>${segmentBadge(r.segment)}</td>
            </tr>
        `).join('');
    } else {
        tbody.innerHTML = emptyState('No reviews found. Click "Load Sample" to get started.');
    }

    // ----- Animated counters -----
    animateCount(container.querySelector('#totalReviews'), total);
    animateCount(container.querySelector('#avgRating'), parseFloat(avgRating));
    animateCount(container.querySelector('#positiveCount'), positive);
    animateCount(container.querySelector('#negativeCount'), negative);
    animateCount(container.querySelector('#segmentCount'), segmentCount);

    // ----- Charts -----
    destroyCharts();

    const sentimentLabels = Object.keys(sentimentDist).length ? Object.keys(sentimentDist) : ['Positive', 'Neutral', 'Negative'];
    const sentimentValues = Object.keys(sentimentDist).length ? Object.values(sentimentDist) : [0, 0, 0];
    charts.push(new Chart(container.querySelector('#sentimentChart'), {
        type: 'doughnut',
        data: {
            labels: sentimentLabels,
            datasets: [{ data: sentimentValues, backgroundColor: ['#4ECDC4', '#FFE66D', '#FF6B6B'], borderWidth: 3, borderColor: '#1A1A2E' }]
        },
        options: {
            responsive: true, maintainAspectRatio: false, cutout: '70%',
            plugins: { legend: { position: 'bottom', labels: { color: '#A8A8B3', padding: 12, usePointStyle: true, pointStyle: 'circle', font: { size: 11 } } } }
        }
    }));

    const ratingLabels = Object.keys(ratingDist).length ? Object.keys(ratingDist).map(r => `${r}⭐`) : ['1⭐', '2⭐', '3⭐', '4⭐', '5⭐'];
    const ratingValues = Object.keys(ratingDist).length ? Object.values(ratingDist) : [0, 0, 0, 0, 0];
    charts.push(new Chart(container.querySelector('#ratingChart'), {
        type: 'bar',
        data: { labels: ratingLabels, datasets: [{ label: 'Reviews', data: ratingValues, backgroundColor: ['#FF6B6B', '#FF8E53', '#FFE66D', '#4ECDC4', '#45B7AA'], borderRadius: 6, borderSkipped: false, barPercentage: 0.6 }] },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { color: '#A8A8B3', stepSize: 1 } }, x: { ticks: { color: '#A8A8B3' } } }
        }
    }));

    const segLabels = Object.keys(segmentDist).length ? Object.keys(segmentDist) : ['No Segments'];
    const segValues = Object.keys(segmentDist).length ? Object.values(segmentDist) : [1];
    charts.push(new Chart(container.querySelector('#segmentChart'), {
        type: 'pie',
        data: { labels: segLabels, datasets: [{ data: segValues, backgroundColor: ['#FF6B6B', '#FFE66D', '#4ECDC4', '#6C5CE7', '#45B7AA'], borderWidth: 3, borderColor: '#1A1A2E' }] },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { position: 'bottom', labels: { color: '#A8A8B3', padding: 12, usePointStyle: true, pointStyle: 'circle', font: { size: 11 } } } }
        }
    }));

    const scatterPoints = reviews.map(r => ({ x: Number(r.rating) || 0, y: r.sentiment_score ?? (r.sentiment_label === 'positive' ? 0.6 : r.sentiment_label === 'negative' ? -0.6 : 0) }));
    charts.push(new Chart(container.querySelector('#scatterChart'), {
        type: 'scatter',
        data: { datasets: [{ label: 'Reviews', data: scatterPoints, backgroundColor: '#FF6B6B', pointRadius: 6, pointHoverRadius: 10 }] },
        options: {
            responsive: true, maintainAspectRatio: false,
            scales: {
                x: { title: { display: true, text: 'Rating', color: '#A8A8B3' }, min: 0, max: 6, ticks: { color: '#A8A8B3', stepSize: 1 } },
                y: { title: { display: true, text: 'Sentiment Score', color: '#A8A8B3' }, min: -1, max: 1, ticks: { color: '#A8A8B3' } }
            },
            plugins: { legend: { labels: { color: '#A8A8B3', usePointStyle: true, pointStyle: 'circle' } } }
        }
    }));

    // ----- Actions -----
    container.querySelector('#btnViewAll').addEventListener('click', () => goTo('reviews'));
    container.querySelectorAll('[data-nav]').forEach(el => el.addEventListener('click', () => goTo(el.dataset.nav)));

    container.querySelector('#btnLoadSample').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        try {
            const res = await api.loadSampleData();
            toast(res.message || 'Sample data loaded');
            await mount(container);
        } catch (err) {
            toast(err.message, true);
        } finally {
            btn.disabled = false;
        }
    });

    container.querySelector('#btnLoadCsv').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        const confirmed = confirm('This loads data/Reviews.csv (your real dataset) into the dashboard. It may take a moment for large files. Continue?');
        if (!confirmed) return;
        btn.disabled = true;
        try {
            const res = await api.loadCsvData(5000);
            toast(res.message || 'Dataset loaded');
            await mount(container);
        } catch (err) {
            toast(err.message, true);
        } finally {
            btn.disabled = false;
        }
    });

    container.querySelector('#btnSegment').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        try {
            const res = await api.runSegmentation();
            toast(res.message || 'Segmentation completed');
            await mount(container);
        } catch (err) {
            toast(err.message, true);
        } finally {
            btn.disabled = false;
        }
    });

    // Live search across the recent-reviews table
    const searchInput = document.getElementById('searchInput');
    const onSearch = () => {
        const filter = searchInput.value.toLowerCase();
        container.querySelectorAll('#reviewsTableBody tr').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(filter) ? '' : 'none';
        });
    };
    searchInput.addEventListener('keyup', onSearch);

    return () => {
        destroyCharts();
        searchInput.removeEventListener('keyup', onSearch);
    };
}
