﻿# test_api_curl.ps1 - Using curl.exe
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "Testing Amazon Review Analysis API" -ForegroundColor Yellow
Write-Host "=" * 60 -ForegroundColor Cyan

# 1. Health Check
Write-Host "`n1. Health Check:" -ForegroundColor Green
curl.exe -s http://localhost:5000/api/v1/health | ConvertFrom-Json | Format-List

# 2. Load Sample Data
Write-Host "`n2. Loading Sample Data:" -ForegroundColor Green
curl.exe -s -X POST http://localhost:5000/api/v1/reviews/load-sample | ConvertFrom-Json | Format-List

# 3. Analyze Sentiment
Write-Host "`n3. Analyzing Sentiment:" -ForegroundColor Green
$body = '{"review_text":"This product is absolutely fantastic! Best purchase ever."}'
curl.exe -s -X POST http://localhost:5000/api/v1/reviews/analyze-sentiment -H "Content-Type: application/json" -d $body | ConvertFrom-Json | Format-List

# 4. Perform Segmentation
Write-Host "`n4. Performing Customer Segmentation:" -ForegroundColor Green
curl.exe -s -X POST http://localhost:5000/api/v1/reviews/segmentation | ConvertFrom-Json | Format-List

# 5. Get Statistics
Write-Host "`n5. Getting Statistics:" -ForegroundColor Green
curl.exe -s http://localhost:5000/api/v1/reviews/stats | ConvertFrom-Json | Format-List

# 6. Get Visualization Data
Write-Host "`n6. Getting Visualization Data:" -ForegroundColor Green
curl.exe -s http://localhost:5000/api/v1/reviews/visualization-data | ConvertFrom-Json | Format-List

Write-Host "`n" + "=" * 60 -ForegroundColor Cyan
Write-Host "✅ API Testing Complete!" -ForegroundColor Green
Write-Host "=" * 60 -ForegroundColor Cyan
