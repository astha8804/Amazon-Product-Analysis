import { api } from '../api.js';
import { stars, sentimentBadge, segmentBadge, truncate, emptyState } from '../utils.js';

export async function mount(container) {
    let viz, health;
    try {
        [viz, health] = await Promise.all([
            api.visualizationData(),
            api.health().catch(() => ({ status: 'unknown' }))
        ]);
    } catch (e) {
        viz = null; health = { status: 'unknown' };
    }

    const totalRecords = viz?.total_reviews ?? 0;
    const sample = (viz?.reviews ?? []).slice(0, 10);
    const isHealthy = health?.status === 'healthy';

    container.innerHTML = `
        <section class="stats-grid">
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Total Records</span><div class="stat-icon"><i class="fa-solid fa-file-alt"></i></div></div>
                <div class="stat-value">${totalRecords}</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Database</span><div class="stat-icon"><i class="fa-solid fa-database"></i></div></div>
                <div class="stat-value" style="font-size:20px;">MongoDB</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">API Status</span><div class="stat-icon"><i class="fa-solid fa-check-circle"></i></div></div>
                <div class="stat-value" style="font-size:20px;">${isHealthy ? 'Active' : 'Unknown'}</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Collections</span><div class="stat-icon"><i class="fa-solid fa-layer-group"></i></div></div>
                <div class="stat-value">1</div>
            </div>
        </section>

        <section class="table-section">
            <div class="table-header">
                <h3><i class="fa-regular fa-list"></i> Recent Records</h3>
                <div class="table-actions">
                    <a href="/download" style="text-decoration:none;"><button><i class="fa-solid fa-download"></i> Export</button></a>
                </div>
            </div>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>#</th><th>Title</th><th>Rating</th><th>Sentiment</th><th>Segment</th></tr></thead>
                    <tbody id="recordsBody"></tbody>
                </table>
            </div>
        </section>
    `;

    const tbody = container.querySelector('#recordsBody');
    tbody.innerHTML = sample.length ? sample.map((r, i) => `
        <tr>
            <td>${i + 1}</td>
            <td>${truncate(r.review_title || 'No Title', 30)}</td>
            <td>${stars(r.rating)}</td>
            <td>${sentimentBadge(r.sentiment_label)}</td>
            <td>${segmentBadge(r.segment)}</td>
        </tr>
    `).join('') : emptyState('No records found. Load sample data to get started.');
}
