﻿# create_venv.ps1
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "Creating Virtual Environment" -ForegroundColor Yellow
Write-Host "=" * 60 -ForegroundColor Cyan

# 1. Check Python
Write-Host "`n1. Checking Python..." -ForegroundColor Green
$pythonVersion = python --version 2>&1
if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Python found: $pythonVersion" -ForegroundColor Green
} else {
    Write-Host "❌ Python not found. Please install Python first." -ForegroundColor Red
    Write-Host "Download from: https://www.python.org/downloads/" -ForegroundColor Yellow
    exit
}

# 2. Remove old venv if exists
Write-Host "`n2. Removing old virtual environment..." -ForegroundColor Green
Remove-Item -Recurse -Force venv -ErrorAction SilentlyContinue

# 3. Create new venv
Write-Host "`n3. Creating new virtual environment..." -ForegroundColor Green
python -m venv venv

# 4. Verify creation
Write-Host "`n4. Verifying creation..." -ForegroundColor Green
if (Test-Path venv) {
    Write-Host "✅ venv folder created" -ForegroundColor Green
} else {
    Write-Host "❌ Failed to create venv" -ForegroundColor Red
    exit
}

if (Test-Path venv\Scripts) {
    Write-Host "✅ Scripts folder created" -ForegroundColor Green
} else {
    Write-Host "❌ Scripts folder not found" -ForegroundColor Red
    exit
}

# 5. Activate
Write-Host "`n5. Activating virtual environment..." -ForegroundColor Green
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
& .\venv\Scripts\Activate.ps1

# 6. Install packages
Write-Host "`n6. Installing packages..." -ForegroundColor Green
pip install flask flask-cors python-dotenv pymongo pandas numpy scikit-learn nltk textblob matplotlib seaborn wordcloud plotly

# 7. Verify installation
Write-Host "`n7. Verifying installation..." -ForegroundColor Green
python -c "import flask; print('✅ Flask installed:', flask.__version__)"
python -c "import pymongo; print('✅ PyMongo installed')"
python -c "import pandas; print('✅ Pandas installed')"

Write-Host "`n" + "=" * 60 -ForegroundColor Cyan
Write-Host "✅ Setup Complete!" -ForegroundColor Green
Write-Host "=" * 60 -ForegroundColor Cyan
Write-Host "`nNow run: python run.py" -ForegroundColor Yellow
