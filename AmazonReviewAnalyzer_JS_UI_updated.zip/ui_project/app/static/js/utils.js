// =====================================================
// INSIGHTCART - SHARED UI HELPERS
// =====================================================

export function escapeHtml(str) {
    return String(str ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

export function stars(rating) {
    const n = Math.max(0, Math.min(5, Math.round(Number(rating) || 0)));
    return '⭐'.repeat(n) || '—';
}

export function sentimentBadge(label) {
    const value = (label || 'neutral').toLowerCase();
    return `<span class="badge badge-${escapeHtml(value)}">${escapeHtml(value)}</span>`;
}

export function segmentBadge(segment) {
    return `<span class="badge badge-segment">${escapeHtml(segment || 'unclassified')}</span>`;
}

export function truncate(str, len) {
    const s = String(str ?? '');
    return s.length > len ? s.slice(0, len) + '…' : s;
}

// Animates a numeric counter from 0 -> target inside el
export function animateCount(el, target) {
    if (!el) return;
    const isFloat = typeof target === 'number' && target % 1 !== 0;
    let current = 0;
    const step = Math.max(target / 40, 0.1);
    const interval = setInterval(() => {
        current += step;
        if (current >= target) {
            current = target;
            clearInterval(interval);
        }
        el.textContent = isFloat ? current.toFixed(1) : Math.floor(current);
    }, 20);
    return () => clearInterval(interval);
}

export function emptyState(message, icon = 'fa-inbox') {
    return `
        <tr>
            <td colspan="6" style="text-align:center;color:var(--text-secondary);padding:36px;">
                <i class="fa-regular ${icon}" style="font-size:24px;display:block;margin-bottom:8px;"></i>
                ${escapeHtml(message)}
            </td>
        </tr>`;
}

export function toast(message, isError = false) {
    let el = document.getElementById('toastBox');
    if (!el) {
        el = document.createElement('div');
        el.id = 'toastBox';
        el.className = 'toast-box';
        document.body.appendChild(el);
    }
    const item = document.createElement('div');
    item.className = 'toast' + (isError ? ' toast-error' : '');
    item.innerHTML = `<i class="fa-solid ${isError ? 'fa-circle-exclamation' : 'fa-circle-check'}"></i> ${escapeHtml(message)}`;
    el.appendChild(item);
    setTimeout(() => {
        item.classList.add('toast-out');
        setTimeout(() => item.remove(), 300);
    }, 3200);
}
