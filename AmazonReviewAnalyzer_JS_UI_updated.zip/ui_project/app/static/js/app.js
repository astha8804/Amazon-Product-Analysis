import { registerRoute, startRouter } from './router.js';
import { api } from './api.js';
import * as dashboard from './pages/dashboard.js';
import * as reviews from './pages/reviews.js';
import * as segments from './pages/segments.js';
import * as analytics from './pages/analytics.js';
import * as database from './pages/database.js';
import * as settings from './pages/settings.js';

registerRoute('dashboard', {
    title: '📊 Dashboard',
    subtitle: 'Real-time Amazon review analytics and insights',
    mount: dashboard.mount
});

registerRoute('reviews', {
    title: '💬 Review Management',
    subtitle: 'Analyze and manage customer reviews',
    mount: reviews.mount
});

registerRoute('segments', {
    title: '👥 Customer Segments',
    subtitle: 'Understanding customer behavior through clustering',
    mount: segments.mount
});

registerRoute('analytics', {
    title: '📈 Advanced Analytics',
    subtitle: 'Deep insights from customer reviews',
    mount: analytics.mount
});

registerRoute('database', {
    title: '🗄️ Database Management',
    subtitle: 'Manage and explore your review database',
    mount: database.mount
});

registerRoute('settings', {
    title: '⚙️ Settings',
    subtitle: 'Manage your application preferences',
    mount: settings.mount
});

// ----- Sidebar toggle for small screens -----
function setupSidebarToggle() {
    const sidebar = document.getElementById('sidebar');
    let toggleBtn = document.getElementById('sidebarToggle');
    if (!toggleBtn) {
        toggleBtn = document.createElement('button');
        toggleBtn.id = 'sidebarToggle';
        toggleBtn.className = 'header-btn sidebar-toggle-btn';
        toggleBtn.innerHTML = '<i class="fa-solid fa-bars"></i>';
        const header = document.querySelector('.top-header');
        header.insertBefore(toggleBtn, header.firstChild);
    }
    toggleBtn.addEventListener('click', () => sidebar.classList.toggle('open'));
}

// ----- Nav review count badge -----
async function refreshNavBadge() {
    try {
        const data = await api.visualizationData();
        const badge = document.getElementById('navReviewCount');
        if (badge) badge.textContent = data?.total_reviews ?? 0;
    } catch (e) {
        // silently ignore - badge just stays at 0
    }
}

// ----- Global refresh button -----
function setupRefreshButton() {
    const btn = document.getElementById('refreshBtn');
    btn.addEventListener('click', () => {
        window.dispatchEvent(new HashChangeEvent('hashchange'));
        refreshNavBadge();
    });
}

setupSidebarToggle();
setupRefreshButton();
refreshNavBadge();
startRouter();
