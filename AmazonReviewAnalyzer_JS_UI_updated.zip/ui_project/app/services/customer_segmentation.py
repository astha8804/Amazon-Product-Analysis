import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import pandas as pd
from typing import List, Dict, Any, Tuple
import logging
from app.config import Config
from app.models.review_model import ReviewModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class CustomerSegmentationService:
    def __init__(self):
        self.scaler = StandardScaler()
        self.kmeans = KMeans(n_clusters=Config.N_CLUSTERS, random_state=42)
        self.pca = PCA(n_components=2)
        self.is_fitted = False
    
    def extract_features(self, reviews: List[Dict[str, Any]]) -> Tuple[np.ndarray, List[str]]:
        features = []
        feature_names = ['rating', 'sentiment_score', 'review_length', 'helpfulness_ratio']
        
        for review in reviews:
            helpfulness = ReviewModel.calculate_helpfulness_ratio(
                review.get('helpful_votes', 0),
                review.get('total_votes', 0)
            )
            
            feature_vector = [
                float(review.get('rating', 0)),
                float(review.get('sentiment_score', 0)),
                float(len(review.get('review_text', ''))),
                float(helpfulness)
            ]
            features.append(feature_vector)
        
        return np.array(features), feature_names
    
    def fit_segmentation(self, reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not reviews:
            logger.warning("No reviews provided for segmentation")
            return {}
        
        features, feature_names = self.extract_features(reviews)
        scaled_features = self.scaler.fit_transform(features)
        self.kmeans.fit(scaled_features)
        self.is_fitted = True
        
        labels = self.kmeans.labels_
        segment_names = self._get_segment_names(scaled_features, labels)
        
        for i, review in enumerate(reviews):
            review['segment'] = segment_names[i]
            distances = self.kmeans.transform(scaled_features[i].reshape(1, -1))
            confidence = 1 / (1 + np.min(distances))
            review['segment_confidence'] = float(confidence)
        
        statistics = self._get_segment_statistics(reviews)
        
        return {
            'segments': statistics,
            'cluster_centers': self.kmeans.cluster_centers_.tolist(),
            'feature_names': feature_names
        }
    
    def predict_segments(self, reviews: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        if not self.is_fitted:
            logger.warning("Model not fitted. Please fit the model first.")
            return reviews
        
        features, _ = self.extract_features(reviews)
        scaled_features = self.scaler.transform(features)
        labels = self.kmeans.predict(scaled_features)
        
        segment_names = self._get_segment_names(scaled_features, labels)
        
        for i, review in enumerate(reviews):
            review['segment'] = segment_names[i]
            distances = self.kmeans.transform(scaled_features[i].reshape(1, -1))
            confidence = 1 / (1 + np.min(distances))
            review['segment_confidence'] = float(confidence)
        
        return reviews
    
    def _get_segment_names(self, features: np.ndarray, labels: np.ndarray) -> List[str]:
        segment_names = []
        segment_characteristics = {}
        
        for label in set(labels):
            mask = labels == label
            segment_features = features[mask]
            
            avg_rating = np.mean(segment_features[:, 0])
            avg_sentiment = np.mean(segment_features[:, 1])
            
            if avg_rating >= 4.0 and avg_sentiment > 0.3:
                name = "Loyal Advocates"
            elif avg_rating >= 4.0 and avg_sentiment <= 0.3:
                name = "Satisfied Customers"
            elif avg_rating >= 3.0 and avg_rating < 4.0:
                name = "Neutral Reviewers"
            elif avg_rating < 3.0 and avg_sentiment < -0.3:
                name = "Critical Reviewers"
            else:
                name = f"Segment_{label}"
            
            segment_characteristics[label] = name
        
        return [segment_characteristics[label] for label in labels]
    
    def _get_segment_statistics(self, reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
        df = pd.DataFrame(reviews)
        
        if 'segment' not in df.columns:
            return {}
        
        statistics = {}
        
        for segment in df['segment'].unique():
            segment_data = df[df['segment'] == segment]
            statistics[segment] = {
                'count': len(segment_data),
                'avg_rating': segment_data['rating'].mean(),
                'avg_sentiment': segment_data['sentiment_score'].mean(),
                'avg_review_length': segment_data['review_text'].str.len().mean(),
                'percentage': (len(segment_data) / len(df)) * 100
            }
        
        return statistics
    
    def reduce_dimensions(self, features: np.ndarray) -> np.ndarray:
        scaled_features = self.scaler.transform(features)
        return self.pca.fit_transform(scaled_features)
    
    def get_segmentation_summary(self, reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not reviews:
            return {}
        
        df = pd.DataFrame(reviews)
        
        summary = {
            'total_segments': df['segment'].nunique() if 'segment' in df.columns else 0,
            'segment_distribution': df['segment'].value_counts().to_dict() if 'segment' in df.columns else {},
            'feature_importance': self._calculate_feature_importance(reviews)
        }
        
        return summary
    
    def _calculate_feature_importance(self, reviews: List[Dict[str, Any]]) -> Dict[str, float]:
        if not self.is_fitted:
            return {}
        
        features, feature_names = self.extract_features(reviews)
        scaled_features = self.scaler.transform(features)
        
        importance = {}
        for i, name in enumerate(feature_names):
            cluster_variances = []
            for label in set(self.kmeans.labels_):
                mask = self.kmeans.labels_ == label
                if np.sum(mask) > 1:
                    cluster_variances.append(np.var(scaled_features[mask, i]))
            importance[name] = np.mean(cluster_variances) if cluster_variances else 0
        
        total = sum(importance.values())
        if total > 0:
            for key in importance:
                importance[key] = (1 - importance[key] / total)
        
        return importance