// =====================================================
// INSIGHTCART - ROUTER
// Minimal hash-based SPA router
// =====================================================

const routes = new Map();
let currentCleanup = null;

export function registerRoute(name, { title, subtitle, mount }) {
    routes.set(name, { title, subtitle, mount });
}

function highlightNav(name) {
    document.querySelectorAll('#sidebarNav a[data-route]').forEach(a => {
        a.classList.toggle('active', a.dataset.route === name);
    });
}

async function renderRoute(name) {
    const route = routes.get(name) || routes.get('dashboard');
    const resolvedName = routes.has(name) ? name : 'dashboard';

    highlightNav(resolvedName);
    document.getElementById('pageTitle').textContent = route.title;
    document.getElementById('pageSubtitle').textContent = route.subtitle;

    const content = document.getElementById('pageContent');
    content.innerHTML = `<div class="loading-state"><i class="fa-solid fa-spinner fa-spin"></i> Loading&hellip;</div>`;

    // Clean up any listeners/intervals/charts from the previous page
    if (typeof currentCleanup === 'function') {
        try { currentCleanup(); } catch (e) { /* ignore */ }
        currentCleanup = null;
    }

    try {
        currentCleanup = await route.mount(content);
    } catch (err) {
        content.innerHTML = `
            <div class="table-section" style="text-align:center;padding:48px;">
                <i class="fa-solid fa-triangle-exclamation" style="font-size:28px;color:var(--primary);display:block;margin-bottom:12px;"></i>
                <p style="color:var(--text-secondary);">Something went wrong loading this page.</p>
                <p style="color:var(--text-secondary);font-size:12px;">${err.message}</p>
            </div>`;
    }

    // On small screens, close the sidebar after navigating
    document.getElementById('sidebar').classList.remove('open');
}

function currentRouteName() {
    const hash = window.location.hash.replace(/^#\/?/, '');
    return hash || 'dashboard';
}

export function startRouter() {
    window.addEventListener('hashchange', () => renderRoute(currentRouteName()));
    if (!window.location.hash) window.location.hash = '#/dashboard';
    renderRoute(currentRouteName());
}

export function goTo(name) {
    window.location.hash = `#/${name}`;
}
