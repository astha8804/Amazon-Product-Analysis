from textblob import TextBlob
import re
from typing import Dict, Any, List
import logging
from app.config import Config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SentimentAnalysisService:
    def __init__(self):
        self.thresholds = Config.SENTIMENT_THRESHOLDS
    
    def clean_text(self, text: str) -> str:
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        text = text.lower()
        text = ' '.join(text.split())
        return text
    
    def analyze_sentiment(self, text: str) -> Dict[str, Any]:
        try:
            cleaned_text = self.clean_text(text)
            blob = TextBlob(cleaned_text)
            
            polarity = blob.sentiment.polarity
            subjectivity = blob.sentiment.subjectivity
            
            if polarity >= self.thresholds['positive']:
                label = 'positive'
            elif polarity <= self.thresholds['negative']:
                label = 'negative'
            else:
                label = 'neutral'
            
            return {
                'sentiment_score': polarity,
                'sentiment_label': label,
                'subjectivity': subjectivity
            }
            
        except Exception as e:
            logger.error(f"Error analyzing sentiment: {e}")
            return {
                'sentiment_score': 0.0,
                'sentiment_label': 'neutral',
                'subjectivity': 0.0
            }
    
    def batch_analyze(self, reviews: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        analyzed_reviews = []
        
        for review in reviews:
            text = review.get('review_text', '')
            if review.get('review_title'):
                text = review['review_title'] + ' ' + text
            
            sentiment = self.analyze_sentiment(text)
            
            review.update({
                'sentiment_score': sentiment['sentiment_score'],
                'sentiment_label': sentiment['sentiment_label'],
                'subjectivity': sentiment['subjectivity']
            })
            
            analyzed_reviews.append(review)
        
        logger.info(f"Analyzed sentiment for {len(analyzed_reviews)} reviews")
        return analyzed_reviews
    
    def get_sentiment_summary(self, reviews: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not reviews:
            return {}
        
        labels = [r.get('sentiment_label', 'neutral') for r in reviews]
        scores = [r.get('sentiment_score', 0) for r in reviews]
        
        summary = {
            'total_reviews': len(reviews),
            'positive_count': labels.count('positive'),
            'negative_count': labels.count('negative'),
            'neutral_count': labels.count('neutral'),
            'avg_sentiment_score': sum(scores) / len(scores) if scores else 0,
            'min_sentiment_score': min(scores) if scores else 0,
            'max_sentiment_score': max(scores) if scores else 0
        }
        
        return summary