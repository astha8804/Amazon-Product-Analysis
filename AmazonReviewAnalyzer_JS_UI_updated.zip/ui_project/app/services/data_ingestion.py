import pandas as pd
import numpy as np
from datetime import datetime
from typing import List, Dict, Any
import logging
from app.database.mongodb_client import MongoDBClient
from app.models.review_model import ReviewModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DataIngestionService:
    def __init__(self):
        self.db_client = MongoDBClient()
    
    # Maps the raw Amazon "Reviews.csv" (Kaggle) column names to our internal schema.
    _AMAZON_COLUMN_MAP = {
        'Id': 'review_id',
        'ProductId': 'product_id',
        'UserId': 'customer_id',
        'Score': 'rating',
        'Text': 'review_text',
        'Summary': 'review_title',
        'HelpfulnessNumerator': 'helpful_votes',
        'HelpfulnessDenominator': 'total_votes',
        'Time': 'date'
    }

    def load_from_csv(self, file_path: str, limit: int = None) -> List[Dict[str, Any]]:
        try:
            if limit:
                df = pd.read_csv(file_path, nrows=limit)
            else:
                df = pd.read_csv(file_path)

            rename_map = {k: v for k, v in self._AMAZON_COLUMN_MAP.items() if k in df.columns}
            if rename_map:
                df = df.rename(columns=rename_map)

            reviews = []
            for _, row in df.iterrows():
                raw_date = row.get('date', None)
                if pd.notna(raw_date) and str(raw_date).replace('.', '', 1).isdigit():
                    try:
                        parsed_date = pd.to_datetime(float(raw_date), unit='s')
                    except Exception:
                        parsed_date = datetime.now()
                else:
                    parsed_date = pd.to_datetime(raw_date) if pd.notna(raw_date) else datetime.now()

                review = {
                    'review_id': str(row.get('review_id', f"rev_{datetime.now().timestamp()}")),
                    'product_id': str(row.get('product_id', 'unknown')),
                    'customer_id': str(row.get('customer_id', 'unknown')),
                    'rating': float(row.get('rating', 0)) if pd.notna(row.get('rating', 0)) else 0.0,
                    'review_text': str(row.get('review_text', '') or ''),
                    'review_title': str(row.get('review_title', '') or ''),
                    'helpful_votes': int(row.get('helpful_votes', 0)) if pd.notna(row.get('helpful_votes', 0)) else 0,
                    'total_votes': int(row.get('total_votes', 0)) if pd.notna(row.get('total_votes', 0)) else 0,
                    'date': parsed_date,
                    'sentiment_score': 0.0,
                    'sentiment_label': 'neutral',
                    'segment': 'unclassified',
                    'segment_confidence': 0.0
                }
                reviews.append(review)

            logger.info(f"Loaded {len(reviews)} reviews from CSV: {file_path}")
            return reviews

        except Exception as e:
            logger.error(f"Error loading CSV: {e}")
            return []
    
    def save_reviews(self, reviews: List[Dict[str, Any]]) -> bool:
        try:
            review_models = [ReviewModel(review).to_dict() for review in reviews]
            result = self.db_client.insert_reviews(review_models)
            return result is not None
            
        except Exception as e:
            logger.error(f"Error saving reviews: {e}")
            return False
    
    def load_sample_data(self):
        sample_reviews = [
            {
                'review_id': f'rev_{i}',
                'product_id': f'prod_{i % 5}',
                'customer_id': f'cust_{i % 10}',
                'rating': np.random.randint(1, 6),
                'review_text': f'This is sample review {i}. Product is great!',
                'review_title': f'Great product {i}',
                'helpful_votes': np.random.randint(0, 100),
                'total_votes': np.random.randint(0, 150),
                'date': datetime.now()
            }
            for i in range(100)
        ]
        return sample_reviews