from datetime import datetime
from typing import Optional, Dict, Any

class ReviewModel:
    def __init__(self, data: Dict[str, Any]):
        self.review_id = data.get('review_id')
        self.product_id = data.get('product_id')
        self.customer_id = data.get('customer_id')
        self.rating = data.get('rating', 0)
        self.review_text = data.get('review_text', '')
        self.review_title = data.get('review_title', '')
        self.helpful_votes = data.get('helpful_votes', 0)
        self.total_votes = data.get('total_votes', 0)
        self.date = data.get('date', datetime.now())
        self.sentiment_score = data.get('sentiment_score', 0.0)
        self.sentiment_label = data.get('sentiment_label', 'neutral')
        self.segment = data.get('segment', 'unclassified')
        self.segment_confidence = data.get('segment_confidence', 0.0)
        
    def to_dict(self) -> Dict[str, Any]:
        return {
            'review_id': self.review_id,
            'product_id': self.product_id,
            'customer_id': self.customer_id,
            'rating': self.rating,
            'review_text': self.review_text,
            'review_title': self.review_title,
            'helpful_votes': self.helpful_votes,
            'total_votes': self.total_votes,
            'date': self.date,
            'sentiment_score': self.sentiment_score,
            'sentiment_label': self.sentiment_label,
            'segment': self.segment,
            'segment_confidence': self.segment_confidence
        }
    
    @staticmethod
    def calculate_helpfulness_ratio(helpful_votes: int, total_votes: int) -> float:
        if total_votes == 0:
            return 0.0
        return helpful_votes / total_votes