from flask import Flask, render_template, send_file, jsonify
from flask_cors import CORS
from app.config import Config
from app.api.routes import api_bp
from app.database.mongodb_client import MongoDBClient
from app.services.data_ingestion import DataIngestionService
from app.services.sentiment_analysis import SentimentAnalysisService
from app.services.customer_segmentation import CustomerSegmentationService
import logging
import pandas as pd
import io

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize services
db_client = MongoDBClient()
ingestion_service = DataIngestionService()
sentiment_service = SentimentAnalysisService()
segmentation_service = CustomerSegmentationService()


def create_app():
    app = Flask(__name__,
                template_folder='templates',
                static_folder='static')
    app.config.from_object(Config)

    CORS(app)
    app.register_blueprint(api_bp, url_prefix='/api/v1')

    # =====================================================
    # SINGLE-PAGE APP SHELL
    # All UI is now rendered client-side in JavaScript
    # (see app/static/js/app.js and app/static/js/pages/*.js).
    # Every front-end route serves the same shell; the JS
    # router (hash-based) swaps in the right page content
    # and talks to the JSON API below.
    # =====================================================
    @app.route('/')
    @app.route('/dashboard')
    @app.route('/reviews')
    @app.route('/segments')
    @app.route('/analytics')
    @app.route('/database')
    @app.route('/settings')
    def spa_shell():
        return render_template('index.html')

    # ===================== DOWNLOAD REPORT =====================
    @app.route('/download')
    def download_report():
        try:
            reviews = db_client.get_all_reviews()
            df = pd.DataFrame(reviews) if reviews else pd.DataFrame()

            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                df.to_excel(writer, index=False, sheet_name='Reviews')

            output.seek(0)

            return send_file(
                output,
                download_name='InsightCart_Report.xlsx',
                as_attachment=True,
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
        except Exception as e:
            logger.error(f"Download error: {e}")
            return jsonify({'error': str(e)}), 500

    # Everything else the JS needs lives under /api/v1 (see app/api/routes.py):
    #   GET  /api/v1/health
    #   GET  /api/v1/reviews/visualization-data
    #   GET  /api/v1/reviews/stats
    #   GET  /api/v1/reviews/segments/<segment>
    #   POST /api/v1/reviews/load-sample
    #   POST /api/v1/reviews/segmentation
    #   POST /api/v1/reviews/upload
    #   POST /api/v1/reviews/analyze-sentiment

    return app


if __name__ == '__main__':
    app = create_app()
    print("=" * 60)
    print("🛒 InsightCart - Amazon Review Analytics")
    print("=" * 60)
    print("📍 Dashboard: http://localhost:5000")
    print("📍 API Docs: http://localhost:5000/api/v1")
    print("=" * 60)
    app.run(debug=True, host='0.0.0.0', port=5000)
