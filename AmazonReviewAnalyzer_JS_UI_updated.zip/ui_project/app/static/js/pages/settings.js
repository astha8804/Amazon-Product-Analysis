import { api } from '../api.js';

export async function mount(container) {
    let stats, health;
    try {
        [stats, health] = await Promise.all([
            api.stats().catch(() => null),
            api.health().catch(() => ({ status: 'unknown' }))
        ]);
    } catch (e) {
        stats = null; health = { status: 'unknown' };
    }

    const totalReviews = stats?.total_reviews ?? 0;
    const isHealthy = health?.status === 'healthy';

    container.innerHTML = `
        <section class="stats-grid">
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Profile</span><div class="stat-icon"><i class="fa-solid fa-user"></i></div></div>
                <div class="stat-value" style="font-size:20px;">Admin</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Database</span><div class="stat-icon"><i class="fa-solid fa-database"></i></div></div>
                <div class="stat-value" style="font-size:20px;">MongoDB</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">API Status</span><div class="stat-icon"><i class="fa-solid fa-check-circle"></i></div></div>
                <div class="stat-value" style="font-size:20px;">${isHealthy ? 'Active' : 'Unknown'}</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Version</span><div class="stat-icon"><i class="fa-solid fa-code"></i></div></div>
                <div class="stat-value" style="font-size:20px;">1.0.0</div>
            </div>
        </section>

        <section class="table-section">
            <div class="table-header"><h3><i class="fa-solid fa-sliders"></i> Configuration</h3></div>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Setting</th><th>Value</th><th>Status</th></tr></thead>
                    <tbody>
                        <tr><td>Database</td><td>MongoDB</td><td><span class="badge badge-positive">Connected</span></td></tr>
                        <tr><td>Segmentation Model</td><td>K-Means</td><td><span class="badge badge-positive">Trained</span></td></tr>
                        <tr><td>Sentiment Analysis</td><td>TextBlob</td><td><span class="badge badge-positive">Active</span></td></tr>
                        <tr><td>Total Reviews</td><td>${totalReviews}</td><td><span class="badge badge-neutral">Loaded</span></td></tr>
                    </tbody>
                </table>
            </div>
        </section>
    `;
}
