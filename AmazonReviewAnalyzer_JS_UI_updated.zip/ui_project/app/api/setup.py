import os
import sys

# Define all files and their content
files = {
    'app/__init__.py': '',
    'app/config.py': '''import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    MONGODB_URI = os.getenv('MONGODB_URI', 'mongodb://localhost:27017/')
    DATABASE_NAME = os.getenv('DATABASE_NAME', 'amazon_review_db')
    COLLECTION_NAME = os.getenv('COLLECTION_NAME', 'reviews')
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key')
    
    SEGMENTATION_FEATURES = ['rating', 'sentiment_score', 'review_length', 'helpfulness_ratio']
    N_CLUSTERS = 4
    
    SENTIMENT_THRESHOLDS = {
        'positive': 0.5,
        'neutral': 0.0,
        'negative': -0.5
    }
''',
    'app/main.py': '''from flask import Flask
from flask_cors import CORS
from app.config import Config
from app.api.routes import api_bp
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    CORS(app)
    app.register_blueprint(api_bp, url_prefix='/api/v1')
    
    @app.route('/')
    def index():
        return {
            'message': 'Amazon Review Analysis API',
            'version': '1.0.0',
            'endpoints': {
                'health': '/api/v1/health',
                'upload_reviews': '/api/v1/reviews/upload',
                'segmentation': '/api/v1/reviews/segmentation',
                'segments': '/api/v1/reviews/segments/<segment>',
                'stats': '/api/v1/reviews/stats',
                'load_sample': '/api/v1/reviews/load-sample',
                'analyze_sentiment': '/api/v1/reviews/analyze-sentiment',
                'visualization_data': '/api/v1/reviews/visualization-data'
            }
        }
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True, host='0.0.0.0', port=5000)
''',
}

# Create all files
for filepath, content in files.items():
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Created: {filepath}")

# Create run.py
run_content = '''#!/usr/bin/env python3
import sys
import os

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.main import create_app

if __name__ == '__main__':
    app = create_app()
    print("=" * 50)
    print("Amazon Review Analysis App")
    print("=" * 50)
    print("Access the API at: http://localhost:5000")
    print("API Documentation: http://localhost:5000")
    print("=" * 50)
    app.run(debug=True, host='0.0.0.0', port=5000)
'''

with open('run.py', 'w', encoding='utf-8') as f:
    f.write(run_content)
print("Created: run.py")

print("\n" + "=" * 50)
print("All files created successfully!")
print("=" * 50)
print("Now run: python run.py")