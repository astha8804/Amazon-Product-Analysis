from flask import Blueprint, request, jsonify
from app.database.mongodb_client import MongoDBClient
from app.services.data_ingestion import DataIngestionService
from app.services.sentiment_analysis import SentimentAnalysisService
from app.services.customer_segmentation import CustomerSegmentationService
from app.config import Config
import logging
import os
import pandas as pd

# Create the blueprint FIRST
api_bp = Blueprint('api', __name__)
logger = logging.getLogger(__name__)

# Initialize services
db_client = MongoDBClient()
ingestion_service = DataIngestionService()
sentiment_service = SentimentAnalysisService()
segmentation_service = CustomerSegmentationService()

# ============== ROUTES ==============

@api_bp.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'message': 'API is running'})

@api_bp.route('/reviews/load-sample', methods=['POST'])
def load_sample_data():
    try:
        sample_reviews = ingestion_service.load_sample_data()
        analyzed_reviews = sentiment_service.batch_analyze(sample_reviews)
        success = ingestion_service.save_reviews(analyzed_reviews)
        
        if success:
            return jsonify({
                'message': 'Sample data loaded successfully',
                'review_count': len(analyzed_reviews)
            }), 201
        else:
            return jsonify({'error': 'Failed to load sample data'}), 500
            
    except Exception as e:
        logger.error(f"Error loading sample data: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/reviews/load-csv', methods=['POST'])
def load_csv_dataset():
    """
    Loads the real Reviews.csv dataset (Amazon reviews export) into the dashboard.
    Body (optional JSON): { "limit": 5000, "file_path": "data/Reviews.csv" }
    """
    try:
        body = request.json or {}
        limit = int(body.get('limit', Config.REVIEWS_CSV_DEFAULT_LIMIT))
        file_path = body.get('file_path', Config.REVIEWS_CSV_PATH)

        if not os.path.exists(file_path):
            return jsonify({
                'error': f'CSV file not found at "{file_path}". Place your Reviews.csv there or pass a file_path.'
            }), 404

        raw_reviews = ingestion_service.load_from_csv(file_path, limit=limit)
        if not raw_reviews:
            return jsonify({'error': 'No rows could be parsed from the CSV'}), 400

        analyzed_reviews = sentiment_service.batch_analyze(raw_reviews)
        success = ingestion_service.save_reviews(analyzed_reviews)

        if success:
            return jsonify({
                'message': f'Loaded {len(analyzed_reviews)} reviews from {file_path}',
                'review_count': len(analyzed_reviews)
            }), 201
        else:
            return jsonify({'error': 'Failed to save reviews to database'}), 500

    except Exception as e:
        logger.error(f"Error loading CSV dataset: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/reviews/segmentation', methods=['POST'])
def perform_segmentation():
    try:
        reviews = db_client.get_all_reviews()
        
        if not reviews:
            return jsonify({'error': 'No reviews found in database'}), 404
        
        segmentation_results = segmentation_service.fit_segmentation(reviews)
        
        for review in reviews:
            db_client.update_review_segment(review['_id'], review['segment'])
        
        return jsonify({
            'message': 'Segmentation completed successfully',
            'segments': segmentation_results.get('segments', {}),
            'total_reviews': len(reviews)
        }), 200
        
    except Exception as e:
        logger.error(f"Error performing segmentation: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/reviews/stats', methods=['GET'])
def get_review_stats():
    try:
        all_reviews = db_client.get_all_reviews()
        
        if not all_reviews:
            return jsonify({'error': 'No reviews found'}), 404
        
        sentiment_summary = sentiment_service.get_sentiment_summary(all_reviews)
        segment_stats = db_client.get_segment_statistics()
        segmentation_summary = segmentation_service.get_segmentation_summary(all_reviews)
        
        return jsonify({
            'total_reviews': len(all_reviews),
            'sentiment_summary': sentiment_summary,
            'segment_statistics': segment_stats,
            'segmentation_summary': segmentation_summary
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting review stats: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/reviews/upload', methods=['POST'])
def upload_reviews():
    try:
        data = request.json
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        reviews = data.get('reviews', [])
        if not reviews:
            return jsonify({'error': 'No reviews found'}), 400
        
        analyzed_reviews = sentiment_service.batch_analyze(reviews)
        success = ingestion_service.save_reviews(analyzed_reviews)
        
        if success:
            return jsonify({
                'message': f'Successfully uploaded {len(analyzed_reviews)} reviews',
                'review_count': len(analyzed_reviews)
            }), 201
        else:
            return jsonify({'error': 'Failed to save reviews'}), 500
            
    except Exception as e:
        logger.error(f"Error uploading reviews: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/reviews/segments/<segment>', methods=['GET'])
def get_reviews_by_segment(segment):
    try:
        reviews = db_client.get_reviews_by_segment(segment)
        
        if not reviews:
            return jsonify({'error': f'No reviews found for segment: {segment}'}), 404
        
        for review in reviews:
            review['_id'] = str(review['_id'])
        
        return jsonify({
            'segment': segment,
            'count': len(reviews),
            'reviews': reviews
        }), 200
        
    except Exception as e:
        logger.error(f"Error fetching reviews by segment: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/reviews/analyze-sentiment', methods=['POST'])
def analyze_review_sentiment():
    try:
        data = request.json
        if not data or 'review_text' not in data:
            return jsonify({'error': 'Review text is required'}), 400
        
        sentiment = sentiment_service.analyze_sentiment(data['review_text'])
        
        return jsonify({
            'sentiment': sentiment,
            'review_text': data['review_text']
        }), 200
        
    except Exception as e:
        logger.error(f"Error analyzing sentiment: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/reviews/visualization-data', methods=['GET'])
def get_visualization_data():
    try:
        reviews = db_client.get_all_reviews()
        
        if not reviews:
            return jsonify({'error': 'No reviews found'}), 404
        
        df = pd.DataFrame(reviews)
        
        if '_id' in df.columns:
            df['_id'] = df['_id'].astype(str)
        
        segment_dist = {}
        if 'segment' in df.columns:
            segment_dist = df['segment'].value_counts().to_dict()
        
        sentiment_dist = {}
        if 'sentiment_label' in df.columns:
            sentiment_dist = df['sentiment_label'].value_counts().to_dict()
        
        rating_dist = {}
        if 'rating' in df.columns:
            rating_dist = df['rating'].value_counts().sort_index().to_dict()
        
        # Convert reviews to list for the table
        reviews_list = []
        for _, row in df.head(50).iterrows():
            reviews_list.append({
                'review_id': str(row.get('review_id', '')),
                'review_title': row.get('review_title', 'No Title'),
                'review_text': row.get('review_text', ''),
                'rating': float(row.get('rating', 0)),
                'sentiment_label': row.get('sentiment_label', 'neutral'),
                'segment': row.get('segment', 'unclassified')
            })
        
        return jsonify({
            'segment_distribution': segment_dist,
            'sentiment_distribution': sentiment_dist,
            'rating_distribution': rating_dist,
            'total_reviews': len(reviews),
            'avg_rating': float(df['rating'].mean()) if 'rating' in df.columns else 0,
            'avg_sentiment': float(df['sentiment_score'].mean()) if 'sentiment_score' in df.columns else 0,
            'reviews': reviews_list
        }), 200
        
    except Exception as e:
        logger.error(f"Error getting visualization data: {e}")
        return jsonify({'error': str(e)}), 500