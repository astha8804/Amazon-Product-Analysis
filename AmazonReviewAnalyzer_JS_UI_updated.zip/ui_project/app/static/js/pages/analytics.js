import { api } from '../api.js';

let charts = [];
function destroyCharts() {
    charts.forEach(c => c.destroy());
    charts = [];
}

export async function mount(container) {
    let viz, stats;
    try {
        [viz, stats] = await Promise.all([api.visualizationData(), api.stats()]);
    } catch (e) {
        viz = null; stats = null;
    }

    const avgRating = viz ? Number(viz.avg_rating || 0).toFixed(1) : '0.0';
    const avgSentiment = viz ? Number(viz.avg_sentiment || 0).toFixed(2) : '0.00';
    const totalReviews = viz?.total_reviews ?? 0;
    const segmentDist = viz?.segment_distribution ?? {};
    const sentimentDist = viz?.sentiment_distribution ?? {};
    const ratingDist = viz?.rating_distribution ?? {};

    const posPct = totalReviews ? Math.round(((sentimentDist.positive || 0) / totalReviews) * 100) : 0;
    const neuPct = totalReviews ? Math.round(((sentimentDist.neutral || 0) / totalReviews) * 100) : 0;
    const negPct = totalReviews ? Math.round(((sentimentDist.negative || 0) / totalReviews) * 100) : 0;

    container.innerHTML = `
        <section class="stats-grid">
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Avg Sentiment Score</span><div class="stat-icon"><i class="fa-regular fa-face-smile"></i></div></div>
                <div class="stat-value">${avgSentiment}</div>
                <div class="stat-change positive">Ranges from -1 to +1</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Average Rating</span><div class="stat-icon"><i class="fa-solid fa-star"></i></div></div>
                <div class="stat-value">${avgRating}</div>
                <div class="stat-change positive">out of 5.0</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Segments</span><div class="stat-icon"><i class="fa-solid fa-users"></i></div></div>
                <div class="stat-value">${Object.keys(segmentDist).length}</div>
                <div class="stat-change positive">Active clusters</div>
            </div>
            <div class="stat-card">
                <div class="stat-header"><span class="stat-label">Total Reviews</span><div class="stat-icon"><i class="fa-solid fa-file-alt"></i></div></div>
                <div class="stat-value">${totalReviews}</div>
                <div class="stat-change positive">Analyzed</div>
            </div>
        </section>

        <section class="charts-grid">
            <div class="chart-card">
                <div class="chart-header"><h3><i class="fa-regular fa-circle"></i> Sentiment Breakdown</h3></div>
                <canvas id="sentimentChart"></canvas>
            </div>
            <div class="chart-card">
                <div class="chart-header"><h3><i class="fa-regular fa-star"></i> Rating Breakdown</h3></div>
                <canvas id="ratingChart"></canvas>
            </div>
        </section>

        <section class="table-section">
            <div class="table-header"><h3><i class="fa-solid fa-chart-simple"></i> Key Insights</h3></div>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Metric</th><th>Value</th><th>Insight</th></tr></thead>
                    <tbody>
                        <tr>
                            <td>Sentiment Distribution</td>
                            <td>${posPct}% Positive, ${neuPct}% Neutral, ${negPct}% Negative</td>
                            <td>${posPct >= negPct ? 'Majority positive feedback' : 'Watch for rising negative feedback'}</td>
                        </tr>
                        <tr>
                            <td>Rating Distribution</td>
                            <td>${Object.entries(ratingDist).map(([r, c]) => `${r}⭐:${c}`).join(', ') || '—'}</td>
                            <td>${avgRating >= 4 ? 'High customer satisfaction' : 'Room for improvement'}</td>
                        </tr>
                        <tr>
                            <td>Top Segments</td>
                            <td>${Object.keys(segmentDist).slice(0, 2).join(', ') || '—'}</td>
                            <td>Focus retention efforts here</td>
                        </tr>
                        <tr>
                            <td>Critical Reviews</td>
                            <td>${negPct}% of total</td>
                            <td>${negPct > 25 ? 'Prioritize service recovery' : 'Under control'}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    `;

    destroyCharts();

    const sentLabels = Object.keys(sentimentDist).length ? Object.keys(sentimentDist) : ['Positive', 'Neutral', 'Negative'];
    const sentValues = Object.keys(sentimentDist).length ? Object.values(sentimentDist) : [0, 0, 0];
    charts.push(new Chart(container.querySelector('#sentimentChart'), {
        type: 'doughnut',
        data: { labels: sentLabels, datasets: [{ data: sentValues, backgroundColor: ['#4ECDC4', '#FFE66D', '#FF6B6B'], borderWidth: 3, borderColor: '#1A1A2E' }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '65%', plugins: { legend: { position: 'bottom', labels: { color: '#A8A8B3' } } } }
    }));

    const ratingLabels = Object.keys(ratingDist).length ? Object.keys(ratingDist).map(r => `${r}⭐`) : ['1⭐', '2⭐', '3⭐', '4⭐', '5⭐'];
    const ratingValues = Object.keys(ratingDist).length ? Object.values(ratingDist) : [0, 0, 0, 0, 0];
    charts.push(new Chart(container.querySelector('#ratingChart'), {
        type: 'bar',
        data: { labels: ratingLabels, datasets: [{ label: 'Reviews', data: ratingValues, backgroundColor: '#6C5CE7', borderRadius: 6 }] },
        options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { y: { ticks: { color: '#A8A8B3' } }, x: { ticks: { color: '#A8A8B3' } } } }
    }));

    return () => destroyCharts();
}
