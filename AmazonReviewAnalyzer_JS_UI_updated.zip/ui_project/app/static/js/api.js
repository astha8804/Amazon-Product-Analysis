// =====================================================
// INSIGHTCART - API CLIENT
// Thin wrapper around fetch() for all backend endpoints
// =====================================================

const BASE = '/api/v1';

async function request(path, options = {}) {
    const res = await fetch(path, {
        headers: { 'Content-Type': 'application/json' },
        ...options
    });
    let body = null;
    try { body = await res.json(); } catch (e) { /* no body */ }
    if (!res.ok) {
        const message = (body && (body.error || body.message)) || `Request failed (${res.status})`;
        throw new Error(message);
    }
    return body;
}

export const api = {
    health: () => request(`${BASE}/health`),

    // Core data hub - powers dashboard, reviews & database pages
    visualizationData: () => request(`${BASE}/reviews/visualization-data`),

    // Aggregated stats - powers segments, analytics & settings pages
    stats: () => request(`${BASE}/reviews/stats`),

    reviewsBySegment: (segment) => request(`${BASE}/reviews/segments/${encodeURIComponent(segment)}`),

    loadSampleData: () => request(`${BASE}/reviews/load-sample`, { method: 'POST' }),

    // Loads the real Reviews.csv dataset (place file at data/Reviews.csv on the server)
    loadCsvData: (limit) => request(`${BASE}/reviews/load-csv`, {
        method: 'POST',
        body: JSON.stringify({ limit: limit || 5000 })
    }),

    runSegmentation: () => request(`${BASE}/reviews/segmentation`, { method: 'POST' }),

    analyzeSentiment: (reviewText) => request(`${BASE}/reviews/analyze-sentiment`, {
        method: 'POST',
        body: JSON.stringify({ review_text: reviewText })
    })
};
