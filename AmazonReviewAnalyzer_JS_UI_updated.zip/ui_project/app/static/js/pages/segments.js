import { api } from '../api.js';
import { toast } from '../utils.js';

const SEGMENT_META = [
    { key: 'loyal_advocates', label: 'Loyal Advocates', icon: 'fa-crown', card: 'card-purple', badge: 'badge-positive', desc: 'High ratings, positive sentiment', strategy: 'Loyalty programs, VIP benefits' },
    { key: 'satisfied_customers', label: 'Satisfied Customers', icon: 'fa-star', card: 'card-blue', badge: 'badge-neutral', desc: 'Good ratings, positive feedback', strategy: 'Cross-selling, recommendations' },
    { key: 'neutral_reviewers', label: 'Neutral Reviewers', icon: 'fa-meh', card: 'card-orange', badge: 'badge-neutral', desc: 'Average ratings, mixed sentiment', strategy: 'Engagement campaigns' },
    { key: 'critical_reviewers', label: 'Critical Reviewers', icon: 'fa-triangle-exclamation', card: 'card-red', badge: 'badge-negative', desc: 'Low ratings, negative sentiment', strategy: 'Improvement, follow-up' }
];

export async function mount(container) {
    let stats;
    try {
        stats = await api.stats();
    } catch (e) {
        stats = null;
    }

    const segmentStats = stats?.segment_statistics ?? {};
    const segmentCount = Object.keys(segmentStats).length || 4;
    const totalReviews = stats?.total_reviews ?? 0;

    container.innerHTML = `
        <section class="table-section" style="margin-bottom:20px;">
            <h3 style="margin-bottom:8px;"><i class="fa-solid fa-bullseye"></i> Segmentation Overview</h3>
            <p style="color:var(--text-secondary);font-size:13px;">${segmentCount} customer segments identified using K-Means clustering across ${totalReviews} reviews.</p>
        </section>

        <section class="stats-grid" id="segmentCards"></section>

        <section class="table-section">
            <div class="table-header">
                <h3><i class="fa-regular fa-list"></i> Segment Strategy Guide</h3>
                <div class="table-actions">
                    <button id="btnRunSegmentation"><i class="fa-solid fa-microchip"></i> Run Segmentation</button>
                </div>
            </div>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Segment</th><th>Description</th><th>Strategy</th><th>Reviews</th></tr></thead>
                    <tbody id="segmentTableBody"></tbody>
                </table>
            </div>
        </section>
    `;

    const cardsEl = container.querySelector('#segmentCards');
    cardsEl.innerHTML = SEGMENT_META.map(seg => `
        <div class="stat-card">
            <div class="stat-header">
                <span class="stat-label">${seg.label}</span>
                <div class="stat-icon"><i class="fa-solid ${seg.icon}"></i></div>
            </div>
            <div class="stat-value" style="font-size:20px;">${segmentStats[seg.key]?.count ?? segmentStats[seg.label] ?? '—'}</div>
            <div class="stat-change positive">${seg.desc}</div>
        </div>
    `).join('');

    const tbody = container.querySelector('#segmentTableBody');
    tbody.innerHTML = SEGMENT_META.map(seg => `
        <tr>
            <td><span class="badge ${seg.badge}">${seg.label}</span></td>
            <td>${seg.desc}</td>
            <td>${seg.strategy}</td>
            <td>${segmentStats[seg.key]?.count ?? segmentStats[seg.label] ?? '—'}</td>
        </tr>
    `).join('');

    container.querySelector('#btnRunSegmentation').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        btn.disabled = true;
        try {
            const res = await api.runSegmentation();
            toast(res.message || 'Segmentation completed');
            await mount(container);
        } catch (err) {
            toast(err.message, true);
        } finally {
            btn.disabled = false;
        }
    });
}
